package epfl

package object pacman {

  import maze.Models._
  
  var model:Model = null
  
}